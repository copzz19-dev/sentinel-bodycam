// ER:LC -> Discord event log webhook.
// Polls join, kill, command and mod call logs and posts new entries as embeds.
// Run alone:  npm run eventlog      Or let server.js start it (ENABLE_EVENT_LOG=true).

const API = 'https://api.policeroleplay.community/v1/server';
const COLORS = { join: 0x5fd0a0, leave: 0x8fa3b8, kill: 0xff6b5a, command: 0x4ea1ff, modcall: 0xf2b84b };

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function who(raw) {
  // The API returns players as "Username:RobloxId"
  const [name, id] = String(raw || 'Unknown:0').split(':');
  return id && id !== '0' ? `[${name}](https://www.roblox.com/users/${id}/profile)` : name;
}
const iso = (ts) => new Date(ts * 1000).toISOString();

export async function erlcFetch(path, key, attempt = 0) {
  const res = await fetch(`${API}${path}`, { headers: { 'server-key': key } });
  if (res.status === 429 && attempt < 3) {
    const body = await res.json().catch(() => ({}));
    await sleep((body.retry_after || 5) * 1000 + 250);
    return erlcFetch(path, key, attempt + 1);
  }
  if (!res.ok) throw new Error(`ER:LC ${path} responded ${res.status}`);
  return res.json();
}

const feeds = [
  {
    name: 'joinlogs',
    id: (e) => `${e.Timestamp}|${e.Player}|${e.Join}`,
    embed: (e) => ({
      title: e.Join ? 'Player joined' : 'Player left',
      description: who(e.Player),
      color: e.Join ? COLORS.join : COLORS.leave,
      timestamp: iso(e.Timestamp),
    }),
  },
  {
    name: 'killlogs',
    id: (e) => `${e.Timestamp}|${e.Killer}|${e.Killed}`,
    embed: (e) => ({
      title: 'Player killed',
      color: COLORS.kill,
      fields: [
        { name: 'Killer', value: who(e.Killer), inline: true },
        { name: 'Victim', value: who(e.Killed), inline: true },
      ],
      timestamp: iso(e.Timestamp),
    }),
  },
  {
    name: 'commandlogs',
    id: (e) => `${e.Timestamp}|${e.Player}|${e.Command}`,
    embed: (e) => ({
      title: 'Command used',
      color: COLORS.command,
      fields: [
        { name: 'Staff', value: who(e.Player), inline: true },
        { name: 'Command', value: '`' + String(e.Command).slice(0, 200).replace(/`/g, "'") + '`' },
      ],
      timestamp: iso(e.Timestamp),
    }),
  },
  {
    name: 'modcalls',
    id: (e) => `${e.Timestamp}|${e.Caller}`,
    embed: (e) => ({
      title: 'Mod call',
      color: COLORS.modcall,
      fields: [
        { name: 'Caller', value: who(e.Caller), inline: true },
        { name: 'Responder', value: e.Moderator ? who(e.Moderator) : 'Unanswered', inline: true },
      ],
      timestamp: iso(e.Timestamp),
    }),
  },
];

export function startEventLog({ key, webhook, pollSeconds = 10 }) {
  if (!key) throw new Error('ERLC_SERVER_KEY is missing');
  if (!webhook) {
    console.warn('[eventlog] DISCORD_WEBHOOK_URL is not set, event log disabled.');
    return;
  }

  const queue = [];
  const seen = Object.fromEntries(feeds.map((f) => [f.name, null])); // null = not seeded yet

  // Sends up to 10 embeds per message, spaced out to respect Discord's rate limit.
  (async function flush() {
    for (;;) {
      if (queue.length) {
        const batch = queue.splice(0, 10);
        try {
          const res = await fetch(webhook, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: 'Sentinel CAD', embeds: batch }),
          });
          if (res.status === 429) {
            const body = await res.json().catch(() => ({}));
            queue.unshift(...batch);
            await sleep(((body.retry_after || 2) + 0.5) * 1000);
          } else if (!res.ok) {
            console.error('[eventlog] Discord rejected the webhook:', res.status);
          }
        } catch (err) {
          queue.unshift(...batch);
          console.error('[eventlog] Discord request failed:', err.message);
        }
      }
      await sleep(2000);
    }
  })();

  async function poll() {
    for (const feed of feeds) {
      try {
        const entries = await erlcFetch(`/${feed.name}`, key);
        if (!Array.isArray(entries)) continue;
        const ids = new Set(entries.map(feed.id));

        // First pass only records what already exists, so old logs are not reposted.
        if (seen[feed.name] === null) {
          seen[feed.name] = ids;
          continue;
        }
        const fresh = entries.filter((e) => !seen[feed.name].has(feed.id(e)));
        fresh.sort((a, b) => a.Timestamp - b.Timestamp);
        for (const e of fresh) queue.push(feed.embed(e));
        seen[feed.name] = ids;
      } catch (err) {
        console.error(`[eventlog] ${feed.name}:`, err.message);
      }
    }
  }

  poll();
  setInterval(poll, Math.max(Number(pollSeconds) || 10, 5) * 1000);
  console.log('[eventlog] Watching joins, kills, commands and mod calls.');
}

// Run directly: node eventlog.js
if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith('eventlog.js')) {
  startEventLog({
    key: process.env.ERLC_SERVER_KEY,
    webhook: process.env.DISCORD_WEBHOOK_URL,
    pollSeconds: process.env.POLL_SECONDS,
  });
}
