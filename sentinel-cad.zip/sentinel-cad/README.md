# Sentinel CAD

## Setup
1. Install Node 20.6 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in your NEW server key, Discord webhook URL, and a CAD password.
4. Run `npm start`, then open http://localhost:3000 and log in (any username, your CAD_PASSWORD).

## Event log only
`npm run eventlog` runs just the Discord webhook, no dashboard.

## Notes
- The server key stays in `.env` on the server. Never put it in the web page or commit it.
- Players who are not on the Civilian team show up as units. Unit statuses and calls are saved to `data.json`.
- The API is rate limited, so keep POLL_SECONDS at 10 or higher.
- To use this over the internet, host it behind HTTPS so the password is not sent in plain text.
