// Sentinel CAD backend. Keeps your server key on the server, never in the browser.
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { erlcFetch, startEventLog } from './eventlog.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const KEY = process.env.ERLC_SERVER_KEY;
const PASSWORD = process.env.CAD_PASSWORD;
const PORT = Number(process.env.PORT) || 3000;
const POLL_MS = Math.max(Number(process.env.POLL_SECONDS) || 10, 5) * 1000;
const DATA_FILE = path.join(__dirname, 'data.json');

if (!KEY) throw new Error('Set ERLC_SERVER_KEY in your .env file.');
if (!PASSWORD || PASSWORD === 'change-me') throw new Error('Set a real CAD_PASSWORD in your .env file.');

// ---------- Storage (simple JSON file) ----------
let db = { nextCallId: 1, calls: [], bolos: [], unitStatus: {} };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) }; } catch { /* first run */ }
let saveTimer;
const save = () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => fs.writeFile(DATA_FILE, JSON.stringify(db, null, 2), () => {}), 300);
};

// ---------- ER:LC live data ----------
const live = { server: null, players: [], modcalls: [], updated: null, error: null };
const parse = (raw) => { const [name, id] = String(raw || '').split(':'); return { name, id }; };

async function refresh() {
  try {
    const [server, players, modcalls] = await Promise.all([
      erlcFetch('', KEY),
      erlcFetch('/players', KEY),
      erlcFetch('/modcalls', KEY),
    ]);
    live.server = server;
    live.players = (players || []).map((p) => ({
      ...parse(p.Player),
      permission: p.Permission,
      callsign: p.Callsign || '',
      team: p.Team || 'Civilian',
    }));
    live.modcalls = (modcalls || []).slice(0, 15).map((m) => ({
      caller: parse(m.Caller).name,
      moderator: m.Moderator ? parse(m.Moderator).name : null,
      time: m.Timestamp,
    }));
    live.updated = Date.now();
    live.error = null;
  } catch (err) {
    live.error = err.message;
  }
}
refresh();
setInterval(refresh, POLL_MS);

// ---------- Web server ----------
const app = express();
app.use(express.json({ limit: '50kb' }));

// Password gate for the dashboard and API (browser shows a login prompt).
app.use((req, res, next) => {
  const header = req.headers.authorization || '';
  const [scheme, encoded] = header.split(' ');
  if (scheme === 'Basic' && encoded) {
    const pass = Buffer.from(encoded, 'base64').toString().split(':').slice(1).join(':');
    if (pass === PASSWORD) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Sentinel CAD"').status(401).send('Login required');
});

app.use(express.static(path.join(__dirname, 'public')));

const OFF_DUTY_TEAMS = new Set(['Civilian']);
const STATUSES = ['Available', 'En Route', 'On Scene', 'Busy', 'Off Duty'];
const CALL_STATUSES = ['Pending', 'Active', 'Closed'];
const clip = (v, n) => String(v ?? '').slice(0, n);

app.get('/api/state', (req, res) => {
  const onlineNames = new Set(live.players.map((p) => p.name));
  const units = live.players
    .filter((p) => !OFF_DUTY_TEAMS.has(p.team))
    .map((p) => ({ ...p, status: db.unitStatus[p.name] || 'Available' }));
  // Drop assignments for players who left, so closed calls don't hold ghost units.
  db.calls.forEach((c) => { if (c.status !== 'Closed') c.units = c.units.filter((u) => onlineNames.has(u)); });
  res.json({
    server: live.server,
    civilians: live.players.filter((p) => OFF_DUTY_TEAMS.has(p.team)).length,
    units,
    modcalls: live.modcalls,
    calls: db.calls.filter((c) => c.status !== 'Closed' || Date.now() - c.closedAt < 30 * 60 * 1000),
    bolos: db.bolos,
    updated: live.updated,
    error: live.error,
    statuses: STATUSES,
    callStatuses: CALL_STATUSES,
  });
});

app.post('/api/calls', (req, res) => {
  const { type, location, description, priority } = req.body || {};
  if (!type || !location) return res.status(400).json({ error: 'Type and location are required.' });
  const call = {
    id: db.nextCallId++,
    type: clip(type, 40),
    location: clip(location, 80),
    description: clip(description, 400),
    priority: ['Low', 'Medium', 'High'].includes(priority) ? priority : 'Medium',
    status: 'Pending',
    units: [],
    notes: [],
    createdAt: Date.now(),
  };
  db.calls.unshift(call);
  save();
  res.json(call);
});

app.patch('/api/calls/:id', (req, res) => {
  const call = db.calls.find((c) => c.id === Number(req.params.id));
  if (!call) return res.status(404).json({ error: 'Call not found.' });
  const { status, attach, detach, note } = req.body || {};
  if (CALL_STATUSES.includes(status)) {
    call.status = status;
    call.closedAt = status === 'Closed' ? Date.now() : undefined;
    if (status === 'Closed') call.units.forEach((u) => { if (db.unitStatus[u] !== 'Off Duty') db.unitStatus[u] = 'Available'; });
  }
  if (attach && live.players.some((p) => p.name === attach) && !call.units.includes(attach)) {
    call.units.push(attach);
    db.unitStatus[attach] = 'En Route';
    if (call.status === 'Pending') call.status = 'Active';
  }
  if (detach) call.units = call.units.filter((u) => u !== detach);
  if (note) call.notes.push({ text: clip(note, 300), at: Date.now() });
  save();
  res.json(call);
});

app.post('/api/units/:name/status', (req, res) => {
  const { status } = req.body || {};
  if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Unknown status.' });
  db.unitStatus[req.params.name] = status;
  save();
  res.json({ ok: true });
});

app.post('/api/bolos', (req, res) => {
  const { subject, details } = req.body || {};
  if (!subject) return res.status(400).json({ error: 'Add who or what to look for.' });
  const bolo = { id: Date.now(), subject: clip(subject, 80), details: clip(details, 300), at: Date.now() };
  db.bolos.unshift(bolo);
  save();
  res.json(bolo);
});

app.delete('/api/bolos/:id', (req, res) => {
  db.bolos = db.bolos.filter((b) => b.id !== Number(req.params.id));
  save();
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`CAD running at http://localhost:${PORT}`));

if (process.env.ENABLE_EVENT_LOG !== 'false') {
  startEventLog({ key: KEY, webhook: process.env.DISCORD_WEBHOOK_URL, pollSeconds: process.env.POLL_SECONDS });
}
